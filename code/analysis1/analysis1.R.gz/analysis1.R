rm(list = ls())

source("/home/soumikp/2022_jmva/code/functions.R")
r = 2500
i = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

data <- minerva::Spellman
#write.csv(data, file.path("/home/soumikp/2022_jmva/data", "analysis1_data.csv"))

x = data$time
y = data[,(i+1)]

obs <- fastkde_minfo(cbind(x, y))
perm <- replicate(r, fastkde_minfo(cbind(x, y[sample(length(y), length(y), replace = F)])))
fastmi <- mean(perm > obs)

jmi <- JMI::JMI(x, y, BN = 2500)$pvalue
op <- c(gene = names(data)[i+1], fastmi = fastmi, jmi = jmi)

output_folder = file.path("/home/soumikp/2022_jmva/output",  paste0("analysis1"),  paste0(names(data)[i+1], "_output.csv"))

write.csv(op, output_folder)
