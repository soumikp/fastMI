rm(list = ls())

## ----setup, include=FALSE, message=FALSE-------------------------------------------------------------------------------------------------------------------------------
library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable, 
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue, 
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom, easycsv
)

dir <- file.path(here(), "output", "analysis1")
setwd(dir)
op <- list.files(dir, pattern = ".csv") %>% 
  map_dfr(~fread(.))

temp <- as_tibble(matrix(op$V2, ncol = 4, byrow= T)[,-1]) %>% 
  mutate(V2 = as.numeric(V2), 
         V3 = as.numeric(V3))

jmi <- temp$V3
names(jmi) <- temp$V1

fastmi <- temp$V2
names(fastmi) <- temp$V1

jmi_hits <- names(jmi[jmi <= 0.05/length(jmi)])
fastmi_hits <- names(fastmi[fastmi <= 0.05/length(fastmi)])

unique_fastmi <- fastmi_hits[fastmi_hits %notin% jmi_hits]

data <- read_csv(file.path(here(), "data", "analysis1_data.csv")) %>% select(-1) %>% 
     select(c("time", unique_fastmi))



plot_title = "Transcript levels of the 35 genes that were detected by fastMI but not by JMI."
plot_subtitle = "The methods compared here are Fast Fourier Transform-based MI (fastMI) and jackknifed MI (JMI)."


p1 <- data %>%
  pivot_longer(cols = -c(time)) %>%
  ggplot(aes(x = time, y = value, group = name)) +
  geom_point(col = "red", size = 1) +
  geom_line() +
  facet_wrap(vars(name), ncol = 5, nrow = 7) +
  theme_bw() +
  theme(legend.position = "bottom",

        axis.text = element_blank(),
        axis.ticks = element_blank(), 
        axis.title = element_text(size = 13),

        strip.text = element_text(size = 12, face = "bold", color = "white"),
        strip.background = element_rect(fill = "black"),

        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12),

        plot.title = element_text(size = 14, face = "bold"),
        plot.subtitle = element_text(size = 13),
        plot.caption = element_text(size = 12, hjust = 0)
  )  +
  scale_x_continuous(expand = c(0.01, 0.01))+
  labs(x = "", y = "", 
       title = plot_title, 
       subtitle = plot_subtitle)

# jmi_adj <- p.adjust(jmi, "BH")
# jmi_hits <- names(which(jmi_adj < 0.05))
# 
# fastmi_adj <- p.adjust(fastmi, "BH")
# fastmi_hits <- names(which(fastmi_adj < 0.05))
# 
# unique_fastmi <- fastmi_hits[fastmi_hits %notin% jmi_hits]
# 
# 
# 
# tophits <-  names(sort(fastmi_adj[names(fastmi_adj) %in% unique_fastmi])[1:8])
# data <- read_csv(file.path(here(), "data", "analysis1_data.csv")) %>% select(-1) %>% 
#   select(c("time", tophits))
# 
# p1 <- data %>% 
#   pivot_longer(cols = -c(time)) %>% 
#   ggplot(aes(x = time, y = value, group = name)) + 
#   geom_point(col = "red") + 
#   geom_smooth(method = "loess", se = FALSE, span = 0.5) + 
#   facet_wrap(vars(name), ncol = 2, nrow = 4) +
#   theme_bw() + 
#   theme(legend.position = "bottom", 
#         
#         axis.text = element_blank(),
#         axis.title = element_text(size = 13), 
#         
#         strip.text = element_text(size = 12, face = "bold", color = "white"), 
#         strip.background = element_rect(fill = "black"),
#         
#         legend.title = element_text(size = 13, face = "bold"), 
#         legend.text = element_text(size = 12), 
#         
#         plot.title = element_text(size = 14, face = "bold"), 
#         plot.subtitle = element_text(size = 13),
#         plot.caption = element_text(size = 12, hjust = 0)
#   )  + 
#   scale_x_continuous(expand = c(0.01, 0.01))+ 
#   labs(x = "", y = "") 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# set.seed(1234)
# examples <- sample(unique_fastmi, 6)
#  
# data <- read_csv(file.path(here(), "data", "analysis1_data.csv")) %>% select(-1) %>% 
#   select(c("time", examples))
# 
# p1 <- data %>% 
#   pivot_longer(cols = -c(time)) %>% 
#   ggplot(aes(x = time, y = value, group = name)) + 
#   geom_point() + 
#   geom_line() + 
#   facet_wrap(vars(name), ncol = 2, nrow = 3)
# 
ggsave(file.path(here(), "analysis1.pdf"),
       p1,
       width = 8.5,
       height = 11,
       units = "in",
       device = "pdf")
