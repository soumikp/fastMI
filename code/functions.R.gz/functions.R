require(reticulate)
require(JMI)
require(rmi)
require(kdecopula)
require(minerva)
suppressPackageStartupMessages(require(HHG))
suppressPackageStartupMessages(require(energy))

#py_install("fastkde", pip = TRUE)
#py_install("pandas")

source_python("/home/soumikp/2022_jmva/code/fastkde_mi.py")

kdecopula_minfo <- function(x){
  mean(
    log(
      kdecopula::dkdecop(apply(x, 2, function(x) rank(x)/(length(x) + 1)), 
                         kdecop(apply(x, 2, function(x) rank(x)/(length(x) + 1)))
      )
    )
  )
}
jackknife_minfo <- function(x){
  JMI(x[,1], x[,2], BN = 0)$mi
}
fastkde_minfo <- function(x){
  fastkde_estim(x[,1], x[,2])
}
ksg_minfo <- function(x){
  abs(knn_mi(cbind(x[,1], x[,2]), c(1, 1), options = list(method = "KSG1", k = 5)))
}
maximal_info <- function(x){
  mine_stat(x[,1], x[,2], measure = "mic")
}


hhg_stat <- function(x){
  d1 = as.matrix(dist(x[,1], diag = TRUE, upper = TRUE)) 
  d2 = as.matrix(dist(x[,2], diag = TRUE, upper = TRUE)) 
  return(hhg.test(d1, d2, nr.perm = 0)$sum.chisq)
}

dcor_stat <- function(x){
  return(dcor(x[,1], x[,2]))
}



minfo_estimates_sim1 <- function(x){
  c(kde = kdecopula_minfo(x), 
    fastkde = fastkde_minfo(x), 
    jmi = jackknife_minfo(x),
    ksg = ksg_minfo(x)
    )
}



minfo_estimates_sim2 <- function(x){
  c(fastkde = fastkde_minfo(x), 
    jmi = jackknife_minfo(x),
    dcor = dcor_stat(x),
    hhg = hhg_stat(x), 
    mic = maximal_info(x)
  )
}

minfo_estimates_analysis2 <- function(x){
  c(fastkde = fastkde_minfo(x), 
    jmi = jackknife_minfo(x),
    mic = maximal_info(x), 
    pearson = cor(x[,1], x[,2], method="pearson"), 
    spearman = cor(x[,1], x[,2], method="spearman"), 
    kendall = cor(x[,1], x[,2], method="kendall")
  )
}





