rm(list = ls())

## ----setup, include=FALSE, message=FALSE-------------------------------------------------------------------------------------------------------------------------------
library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable, 
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue, 
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom
)


source("/home/soumikp/2022_jmva/code/functions.R")
source("/home/soumikp/2022_jmva/code/simulation1/simulation1_patterns.R")

dir <- file.path(here(), "output", "simulation1")
files <- list.files(dir, pattern = ".csv") 


mse <- function(estim, true){
  mean((estim - true)**2)
}

results <- NULL



for(f in files){
  file = file.path(dir, f)
  op <- read.csv(file)
  names <- op %>% pull(1)
  op <- t(as.matrix(op[,-1]))
  colnames(op) <- names
  
  p = as.numeric((str_split(f, "_")[[1]])[1])
  n = as.numeric((str_split(f, "_")[[1]])[2])
  tau = as.numeric((str_split(f, "_")[[1]])[3])
  
  true_mi = ifelse(p == 1, tau_mi_gaussian(tau), 
                ifelse(p == 2, tau_mi_gumbel(tau), 
                       ifelse(p == 3, tau_mi_frank(tau), tau_mi_clayton(tau))))
  
  results <- rbind(results, 
                   c(p, n, tau, true_mi,  apply(op, 2, mse, true = true_mi)))
}


colnames(results) <- c("p", "n", "tau", "mi", "kde", "fkde", "jmi", "ksg")
results = as.tibble(results)



# latex_lines <- function(each_line) { # spread each entry in each_line onto a different line using overset, wrapping each line in normalsize
#   if ("character" != class(each_line)) {
#     stop("latex_lines expects a character vector")
#   }
#   ret <- paste0("\\normalsize{", each_line[1], "}")
#   while(0 != length(each_line <- tail(each_line, n=-1))) {
#     ret <- paste0("\\overset{", ret, "}{\\normalsize{", each_line[1],"}}")
#   }
#   return(ret)
# }


plot_title = "Comparison of mean squared error (MSE) of competing mutual information (MI) \nestimation methods for various copula families."
plot_subtitle = "The estimation methods compared here are Fast Fourier Transform-based MI (fastMI) and \nthe jackknifed MI (JMI)."


p = results %>%
  select(-c(kde, ksg)) %>% 
  filter(p != 3) %>%
  filter(n != 500) %>% 
  pivot_longer(cols = -c(n, tau, mi, p)) %>% 
  mutate(p = case_when(p == 1 ~  "Gaussian copula", 
                       p == 2 ~ "Gumbel copula", 
                       p == 3 ~ "Frank copula", 
                       p == 4 ~ "Clayton copula")) %>% 
  mutate(name = case_when(name == "kde" ~ "KDE", 
                          name == "fkde" ~ "fastMI", 
                          name == "jmi" ~ "JMI", 
                          name == "ksg" ~ "KSG (k = 3)")) %>% 
  mutate(n = paste0("n = ", n)) %>% 
  ggplot(aes(x = tau, y = value, color = name, linetype = name)) + 
  #geom_smooth(method = "loess", se = FALSE, linewidth = 1) + 
  #geom_point() + 
  geom_line(linewidth = 1) + 
  facet_grid(cols = vars(p), 
             rows = vars(n)) + 
  xlab(TeX("Kendall's $\\tau$")) + 
  ylab("MSE") + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 13), 
        
        strip.text = element_text(size = 12, face = "bold", color = "white"), 
        strip.background = element_rect(fill = "black"),
        
        legend.title = element_text(size = 13, face = "bold"), 
        legend.text = element_text(size = 12), 
        
        plot.title = element_text(size = 14, face = "bold"), 
        plot.subtitle = element_text(size = 13),
        plot.caption = element_text(size = 12, hjust = 0)
        ) + 
  labs(color = "Estimation method",
       linetype = "Estimation method") + 
  scale_color_aaas() + 
  labs(title = plot_title, subtitle = plot_subtitle) + 
  scale_x_continuous(expand = c(0.01, 0.01)) 
  


ggsave(file.path(here(), "simulation1_figure.pdf"), 
       p,
       width = 8.5,
       height = 11,
       units = "in",
       device = "pdf")


pct_helper <- function(x){
  jmi = max(x)
  fastmi = min(x)
  return(round(100*(jmi - fastmi)/jmi, 1))
}

txt_helper <- function(x){
  paste0(x[1], " (", x[2], ")")
}

pct_error <- results %>%
  select(-c(kde, ksg)) %>% 
  filter(p != 3) %>%
  pivot_longer(cols = -c(n, tau, mi, p)) %>% 
  mutate(p = case_when(p == 1 ~  "Gaussian copula", 
                       p == 2 ~ "Gumbel copula", 
                       p == 3 ~ "Frank copula", 
                       p == 4 ~ "Clayton copula")) %>% 
  mutate(name = case_when(name == "kde" ~ "KDE", 
                          name == "fkde" ~ "fastMI", 
                          name == "jmi" ~ "JMI", 
                          name == "ksg" ~ "KSG (k = 3)")) %>% 
  mutate(n = paste0("n = ", n)) %>%
  select(-c(mi)) %>%
  group_by(p, n, tau) %>% 
  summarise(pct = pct_helper(value)) %>%
  filter(n != "n = 500") %>%  
  group_by(p, tau) %>%
  summarise(t = txt_helper(pct)) %>%
  pivot_wider(names_from = tau, values_from = t) %>% 
  write_csv(file.path(here(), "simulation1_table.csv"))
  
  
