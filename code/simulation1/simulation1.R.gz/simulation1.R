source("/home/soumikp/2022_jmva/code/functions.R")
source("/home/soumikp/2022_jmva/code/simulation1/simulation1_patterns.R")

require(tidyverse)


values = expand.grid(n = c(100, 250, 500), 
            pattern = 1:4, 
            tau = sort(c((0:9/10), 0.25, 0.75)))

i = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

n = values[i, 1]
pattern = values[i, 2]
tau = values[i, 3]

niter = 1000

if(pattern == 1){
  op <- replicate(niter, 
                  minfo_estimates_sim1(rgaussian(theta = tau_theta_gaussian(tau), n = n)))
  
}
if(pattern == 2){
  op <- replicate(niter, 
                  minfo_estimates_sim1(rgumbel(theta = tau_theta_gumbel(tau), n = n)))
  
}
if(pattern == 3){
  op <- replicate(niter, 
                  minfo_estimates_sim1(rfrank(theta = tau_theta_frank(tau), n = n)))
  
}
if(pattern == 4){
  op <- replicate(niter, 
                  minfo_estimates_sim1(rclayton(theta = tau_theta_clayton(tau), n = n)))
  
}

output_folder = file.path("/home/soumikp/2022_jmva/output",  paste0("simulation1"),  paste0(pattern, "_", n, "_", tau, "_output.csv"))
write.csv(op, output_folder)