#source("/home/soumikp/jmva/code/2022_11_28_functions.R")
#require(patchwork)

#plot = FALSE


scatterplot <- function(x){
  as_tibble(x) %>% ggplot(aes(x = x, y = y)) + geom_point()
}

## linear
add_pattern1 <- function(a, n = 500){
  x <- runif(n, -1, 1)
  err <- rnorm(n, 0, 0.5)
  y <- a*x + err
  return(cbind(x, y))
}
# if(plot){
#   scatterplot(add_pattern1(0)) + ggtitle("Pattern 1: a = 0") + 
#     scatterplot(add_pattern1(1)) + ggtitle("Pattern 1: a = 1") + 
#     scatterplot(add_pattern1(2)) + ggtitle("Pattern 1: a = 2") + 
#     scatterplot(add_pattern1(4)) + ggtitle("Pattern 1: a = 4")
# }


## quadratic
add_pattern2 <- function(a, n = 500){
  x <- runif(n, -1, 1)
  err <- rnorm(n, 0, 0.1)
  y <- a*x*x + err
  cbind(x, y)
}
# scatterplot(add_pattern2(0)) + ggtitle("Pattern 2: a = 0") + 
#   scatterplot(add_pattern2(1)) + ggtitle("Pattern 2: a = 0.25") + 
#   scatterplot(add_pattern2(2)) + ggtitle("Pattern 2: a = 0.50") + 
#   scatterplot(add_pattern2(4)) + ggtitle("Pattern 2: a = 1")


## circular
add_pattern3 <- function(a, n = 500){
  theta = runif(n)
  x = cos(2*pi*theta)
  y = a*sin(2*pi*theta) + rnorm(n, 0, 0.1)
  cbind(x, y)
}
# scatterplot(add_pattern3(0)) + ggtitle("Pattern 2: a = 0") + 
#   scatterplot(add_pattern3(0.125)) + ggtitle("Pattern 2: a = 0.25") + 
#   scatterplot(add_pattern3(0.25)) + ggtitle("Pattern 2: a = 0.50") + 
#   scatterplot(add_pattern3(0.50)) + ggtitle("Pattern 2: a = 1")

## spiral
add_pattern4 <- function(a, n = 500){
  theta = runif(n, 0, 4)
  x = theta*sin(pi*theta)
  y = a*theta*cos(pi*theta) + rnorm(n, 0, 0.1)
  cbind(x, y)
}
# scatterplot(add_pattern4(0)) + ggtitle("Pattern 2: a = 0") + 
#   scatterplot(add_pattern4(0.125)) + ggtitle("Pattern 2: a = 0.25") + 
#   scatterplot(add_pattern4(0.25)) + ggtitle("Pattern 2: a = 0.50") + 
#   scatterplot(add_pattern4(0.50)) + ggtitle("Pattern 2: a = 1")
# 
# ## cloud
# add_pattern5 <- function(a, n = 500){
#   
# }

