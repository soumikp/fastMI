rm(list = ls())

source("/home/soumikp/2022_jmva/code/functions.R")
#r = 2500
i = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))


library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, HellCor, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable, 
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue, 
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom, easycsv
)

data <- HellCor::worlddemographics

x = data$Birth.Rate.Pop
y = data$Death.Rate.Pop

if(i == 1){
  op = minfo_estimates_analysis2(cbind(x, y))
}else{
  op = minfo_estimates_analysis2(cbind(x, y[sample(length(y), length(y), replace = F)]))
}

output_folder = file.path("/home/soumikp/2022_jmva/output",  "analysis2", paste0(i, "_output.csv"))

write.csv(op, output_folder)
