#rm(list = ls())

## ----setup, include=FALSE, message=FALSE-------------------------------------------------------------------------------------------------------------------------------
library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, countrycode, HellCor, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable,
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue,
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom, easycsv
)

# dir <- file.path(here(), "output", "analysis2")
# setwd(dir)
# op <- list.files(dir, pattern = ".csv") %>%
#   map_dfr(~fread(.))
# 
# temp <- as_tibble(matrix(op$x, ncol = 6, byrow= T))
# colnames(temp) <- op$V1[1:6]
# 
pval_helper <- function(x){
  obs <- x[1]
  perm <- x[-1]
  sum(abs(perm) > abs(obs))/length(perm)
}

op <- paste0(round(temp[1, ], 3),
       "[",
       round(apply(temp, 2, pval_helper), 3),
       "]")

op



plot_data <- as_tibble(HellCor::wdemographics) %>% 
  mutate(Country_ISO = countrycode(Country, origin = 'country.name', destination = 'iso3c'),
         continent = countrycode(Country, origin = 'country.name', destination = 'continent')) %>%
  drop_na()



plot_title = "Birth rate versus death rate (per thousand individuals) around the world in 2020."
plot_subtitle = "These data are made available in the R package HellCor.\nCountries are color-/shape-coded by their continent."


p <- plot_data %>% 
  ggplot(aes(y = Birth.Rate.Pop, x = Death.Rate.Pop)) + 
  geom_point(aes(color = continent, shape = continent), size = 2.5)  + 
  annotate("text", x = 12.5, y = 20, label = TeX("fastMI (p-value) = 0.333 ($< 2 \\times 10^{-4}$)"), hjust = 0.5, size = 4) +
  annotate("text", x = 12.5, y = 18, label = TeX("JMI (p-value) = 0.451 ($< 2 \\times 10^{-4}$)"), hjust = 0.5, size = 4) +
  annotate("text", x = 12.5, y = 16, label = TeX("Pearson's $r$ (p-value) = -0.125 ($0.97$)"), hjust = 0.5, size = 4) +
  #geom_text(aes(label = Country_ISO)) +
  scale_color_aaas() + 
  theme_bw() +
  theme(legend.position = "bottom",

        #axis.text = element_blank(),
        #axis.ticks = element_blank(),
        axis.title = element_text(size = 13),
        axis.text = element_text(size = 12),

        strip.text = element_text(size = 12, face = "bold", color = "white"),
        strip.background = element_rect(fill = "black"),

        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12),

        plot.title = element_text(size = 14, face = "bold"),
        plot.subtitle = element_text(size = 13),
        plot.caption = element_text(size = 12, hjust = 0)
  )  +
  scale_x_continuous(expand = c(0.01, 0.01))+
  labs(x = "Deaths/1000 population", y = "Births/1000 population",
       color = "Continent", 
       shape = "Continent", 
       title = plot_title,
       subtitle = plot_subtitle)


# 
# p1 <- data %>%
#   pivot_longer(cols = -c(time)) %>%
#   ggplot(aes(x = time, y = value, group = name)) +
#   geom_point(col = "red", size = 1) +
#   geom_line() +
#   facet_wrap(vars(name), ncol = 5, nrow = 7) +
#   theme_bw() +
#   theme(legend.position = "bottom",
# 
#         axis.text = element_blank(),
#         axis.ticks = element_blank(), 
#         axis.title = element_text(size = 13),
# 
#         strip.text = element_text(size = 12, face = "bold", color = "white"),
#         strip.background = element_rect(fill = "black"),
# 
#         legend.title = element_text(size = 13, face = "bold"),
#         legend.text = element_text(size = 12),
# 
#         plot.title = element_text(size = 14, face = "bold"),
#         plot.subtitle = element_text(size = 13),
#         plot.caption = element_text(size = 12, hjust = 0)
#   )  +
#   scale_x_continuous(expand = c(0.01, 0.01))+
#   labs(x = "", y = "", 
#        title = plot_title, 
#        subtitle = plot_subtitle)

# jmi_adj <- p.adjust(jmi, "BH")
# jmi_hits <- names(which(jmi_adj < 0.05))
# 
# fastmi_adj <- p.adjust(fastmi, "BH")
# fastmi_hits <- names(which(fastmi_adj < 0.05))
# 
# unique_fastmi <- fastmi_hits[fastmi_hits %notin% jmi_hits]
# 
# 
# 
# tophits <-  names(sort(fastmi_adj[names(fastmi_adj) %in% unique_fastmi])[1:8])
# data <- read_csv(file.path(here(), "data", "analysis1_data.csv")) %>% select(-1) %>% 
#   select(c("time", tophits))
# 
# p1 <- data %>% 
#   pivot_longer(cols = -c(time)) %>% 
#   ggplot(aes(x = time, y = value, group = name)) + 
#   geom_point(col = "red") + 
#   geom_smooth(method = "loess", se = FALSE, span = 0.5) + 
#   facet_wrap(vars(name), ncol = 2, nrow = 4) +
#   theme_bw() + 
#   theme(legend.position = "bottom", 
#         
#         axis.text = element_blank(),
#         axis.title = element_text(size = 13), 
#         
#         strip.text = element_text(size = 12, face = "bold", color = "white"), 
#         strip.background = element_rect(fill = "black"),
#         
#         legend.title = element_text(size = 13, face = "bold"), 
#         legend.text = element_text(size = 12), 
#         
#         plot.title = element_text(size = 14, face = "bold"), 
#         plot.subtitle = element_text(size = 13),
#         plot.caption = element_text(size = 12, hjust = 0)
#   )  + 
#   scale_x_continuous(expand = c(0.01, 0.01))+ 
#   labs(x = "", y = "") 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# set.seed(1234)
# examples <- sample(unique_fastmi, 6)
#  
# data <- read_csv(file.path(here(), "data", "analysis1_data.csv")) %>% select(-1) %>% 
#   select(c("time", examples))
# 
# p1 <- data %>% 
#   pivot_longer(cols = -c(time)) %>% 
#   ggplot(aes(x = time, y = value, group = name)) + 
#   geom_point() + 
#   geom_line() + 
#   facet_wrap(vars(name), ncol = 2, nrow = 3)
# 
ggsave(file.path(here(), "analysis2.pdf"),
       p,
       width = 8.5,
       height = 11,
       units = "in",
       device = "pdf")
