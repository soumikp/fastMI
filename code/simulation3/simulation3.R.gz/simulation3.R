source("/home/soumikp/2022_jmva/code/functions.R")
source("/home/soumikp/2022_jmva/code/simulation2/simulation2_patterns.R")

simulation = 3

sampsize = as.numeric(Sys.getenv("sampsize"))
iteration = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

true <- rgaussian(tau_theta_gaussian(0.5), n = sampsize)

# op <- microbenchmark::microbenchmark(jmi = jackknife_minfo(true),
#                                      fkde = fastkde_minfo(true),
#                                      mic = maximal_info(true),
#                                      ksg = ksg_minfo(true),
#                                      times = 1,
#                                      unit = "s")

op <- c(n = sampsize, 
        i = iteration, 
        jmi = system.time(jackknife_minfo(true))[3],
        fkde = system.time(fastkde_minfo(true))[3],
        mic = system.time(maximal_info(true))[3],
        ksg = system.time(ksg_minfo(true))[3])


output_folder = file.path("/home/soumikp/2022_jmva/output", 
                          paste0("simulation", simulation), 
                          paste0(sampsize, "_", iteration, "_output.csv")
                          )

write.csv(op, output_folder)
