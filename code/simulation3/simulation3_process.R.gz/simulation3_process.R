rm(list = ls())

## ----setup, include=FALSE, message=FALSE-------------------------------------------------------------------------------------------------------------------------------
library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable, table1,
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue, 
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom
)

dir <- file.path(here(), "output", "simulation3")
files <- list.files(dir, pattern = ".csv")


results = NULL


for(f in files){
  file = file.path(dir, f)
  temp <- suppressMessages(read_csv(file) %>% pull(x))
  results <- rbind(results, temp)
}


colnames(results) <- c("n", "iter", "jmi", "fkde", "mic", "ksg")
results = as.tibble(results)



plot_figure = F
if(plot_figure == T){
  plot_title = "Comparison of computation time of competing mutual information (MI) \nestimation methods for various sample sizes."
  plot_subtitle = "The estimation methods compared here are Fast Fourier Transform-based MI (FFT-MI), the \njackknifed MI (JMI), the maximal information coefficient (MIC), and the Kraskov-Stogbauer-\nGrassberger (KSG) estimator."
  
  p = results %>% 
    group_by(n) %>% 
    summarise(m_jmi = mean(jmi), 
              m_fkde = mean(fkde), 
              m_mic = mean(mic), 
              m_ksg = mean(ksg), 
              s_jmi = sd(jmi), 
              s_fkde = sd(fkde), 
              s_mic = sd(mic), 
              s_ksg = sd(ksg)) %>% 
    select(c(n, m_jmi, m_fkde, m_mic, m_ksg)) %>% 
    pivot_longer(-c(n)) %>% 
    mutate(name = case_when(name == "m_mic" ~ "MIC", 
                            name == "m_fkde" ~ "FFT-MI", 
                            name == "m_jmi" ~ "JMI", 
                            name == "m_ksg" ~ "KSG (k = 3)")) %>% 
    ggplot(aes(x = log(n), y = value, color = name)) +
    geom_line() + 
    #geom_smooth(method = "loess", se = FALSE, linewidth = 0.5) + 
    #geom_hline(yintercept = 0.05, linetype = "dashed", color = "black") + 
    #facet_grid(cols = vars(n),  rows = vars(p)) + 
    xlab(TeX("log-transformed sample size $\\log(n)$")) + 
    ylab("Computation time (in seconds)") + 
    theme_bw() + 
    theme(legend.position = "bottom", 
          
          axis.text = element_text(size = 12),
          axis.title = element_text(size = 13), 
          
          strip.text = element_text(size = 12, face = "bold", color = "white"), 
          strip.background = element_rect(fill = "black"),
          
          legend.title = element_text(size = 13, face = "bold"), 
          legend.text = element_text(size = 12), 
          
          plot.title = element_text(size = 14, face = "bold"), 
          plot.subtitle = element_text(size = 13),
          plot.caption = element_text(size = 12, hjust = 0)
    ) + 
    labs(color = "Estimation method") + 
    scale_color_aaas() + 
    labs(title = plot_title, subtitle = plot_subtitle) 
  
  
  ggsave(file.path(here(), "simulation3.pdf"), 
         p,
         width = 8.5,
         height = 11,
         units = "in",
         device = "pdf")
}

if(plot_table == T){}

round(results %>% 
  group_by(n) %>% 
  summarise(m_jmi = mean(jmi), 
            m_fkde = mean(fkde), 
            m_mic = mean(mic), 
            m_ksg = mean(ksg), 
            s_jmi = sd(jmi), 
            s_fkde = sd(fkde), 
            s_mic = sd(mic), 
            s_ksg = sd(ksg)), 3) %>% 
  select(matches("jmi|fkde|n")) %>% 
  mutate(text_jmi = paste0(m_jmi, "(", s_jmi, ")"),
         text_fmi = paste0(m_fkde, "(", s_fkde, ")")) %>% 
  select(matches("text|n"))
