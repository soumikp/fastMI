#!/bin/bash

for i in $( echo 2500 5000 10000); do
  export sampsize=$i
  sbatch /home/soumikp/2022_jmva/code/simulation3/simulation3_base.sh
done