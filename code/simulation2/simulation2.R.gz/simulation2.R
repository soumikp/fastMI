source("/home/soumikp/2022_jmva/code/functions.R")
source("/home/soumikp/2022_jmva/code/simulation2/simulation2_patterns.R")

simulation = 2

r = 250

pattern = as.numeric(Sys.getenv("pattern"))
sampsize = as.numeric(Sys.getenv("sampsize"))
val_tau = as.numeric(Sys.getenv("signal"))
iteration = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

if(pattern == 1){ ## gaussian
  true = rgaussian(tau_theta_gaussian(val_tau), n = sampsize)
}
if(pattern == 2){ ## gumbel 
  true = rgumbel(tau_theta_gumbel(val_tau), n = sampsize)
}
if(pattern == 3){ ## frank
  true = rfrank(tau_theta_frank(val_tau), n = sampsize)
}
if(pattern == 4){ ## clayton
  true = rclayton(tau_theta_clayton(val_tau), n = sampsize)
}

# microbenchmark::microbenchmark(minfo_estimates_sim2(true), times = 50) 
# Unit: milliseconds
# expr                          min       lq     mean   median       uq      max    neval
# minfo_estimates_sim2(true) 383.4515 384.5443 389.2114 384.9917 388.5195 423.2201    50

obs <- minfo_estimates_sim2(true)

perm <- replicate(r, minfo_estimates_sim2(cbind(true[,1], true[sample(nrow(true), nrow(true)),2])))

pval_helper <- function(x){
  obs <- x[length(x)]
  perm <- x[-length(x)]
  return(sum(perm>obs)/length(perm))
}

pvals <- c(pattern, sampsize, val_tau, iteration, apply(rbind(t(perm), obs), 2, pval_helper))

output_folder = file.path("/home/soumikp/2022_jmva/output", 
                          paste0("simulation", simulation), 
                          paste0(pattern, "_", sampsize, "_", val_tau, "_", iteration, "_output.csv")
                          )

write.csv(pvals, output_folder)
