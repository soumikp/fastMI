#!/bin/bash

export pattern=3

for i in $( echo 100 200); do
  for j in $( seq 0 0.05 0.5); do
    export sampsize=$i
    export signal=$j
    sbatch /home/soumikp/2022_jmva/code/simulation2/simulation2_base.sh
  done
done