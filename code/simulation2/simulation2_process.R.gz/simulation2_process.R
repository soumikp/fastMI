rm(list = ls())

## ----setup, include=FALSE, message=FALSE-------------------------------------------------------------------------------------------------------------------------------
library(pacman)

`%notin%` <- Negate(`%in%`)

p_load(
  #--- Packages to Fit Models
  MASS, logistf, survival, randcorr, JMI, 
  #--- Packages to Produce Tables
  gtsummary, flextable, janitor, broom, officer, kableExtra, reactable, 
  #--- Packages to Produce Figures
  crayon, ggsci, ggridges, ggthemes, ggforce, ggpubr, patchwork, grid, gridExtra, plotly,  survminer, viridis, ggridges, hrbrthemes, latex2exp, scales, glue, 
  #--- Packages for Data Retrieval & Pre-Processing
  readxl, here, rdrop2, lubridate, zoo, tidyverse, purrr, data.table, stringr, tidyr, vroom
)

dir <- file.path(here(), "output", "simulation2")
files <- list.files(dir, pattern = ".csv")

results = NULL


for(f in files){
  file = file.path(dir, f)
  temp <- read.csv(file) %>% pull(x)
  results <- rbind(results, temp)
}


colnames(results) <- c("p", "n", "tau", "iter", "fkde", "jmi", "dcor", "hhg", "mic")
results = as.tibble(results)


pval_helper <- function(x){
  return(sum(x <= 0.05)/length(x))
}

results <- results %>% 
  group_by(p, n, tau) %>% 
  summarise(fkde = pval_helper(fkde), 
            jmi = pval_helper(jmi), 
            dcor = pval_helper(dcor), 
            hhg = pval_helper(hhg), 
            mic = pval_helper(mic)) %>% 
  ungroup()


plot_title = "Comparison of empirical power of competing mutual information (MI) \nestimation methods for various association patterns."
plot_subtitle = "The estimation methods compared here are Fast Fourier Transform-based MI (fastMI), the \njackknifed MI (JMI) and the maximal information coefficient (MIC)."



p = results  %>% 
  select(-c(dcor, hhg, mic)) %>% 
  pivot_longer(cols = -c(p, n, tau)) %>% 
  mutate(n = case_when(n == 200 ~ 250, 
                       TRUE ~ n)) %>%
  filter(p != 3) %>% 
  mutate(p = case_when(p == 1 ~  "Gaussian copula", 
                       p == 2 ~ "Gumbel copula", 
                       p == 3 ~ "Frank copula", 
                       p == 4 ~ "Clayton copula")) %>% 
  mutate(name = case_when(name == "mic" ~ "MIC", 
                          name == "fkde" ~ "fastMI", 
                          name == "jmi" ~ "JMI", 
                        name == "dcor" ~ "dCor", 
                        name == "hhg" ~ "HHG")) %>% 
  mutate(n = paste0("n = ", n)) %>%  
  ggplot(aes(x = tau, y = value, color = name)) + 
  #geom_line(linewidth = 0.5) + 
  geom_smooth(method = "gam", se = FALSE, linewidth = 0.5) + 
  geom_hline(yintercept = 0.05, linetype = "dashed", color = "black") + 
  facet_grid(cols = vars(p), 
             rows = vars(n)) + 
  xlab(TeX("Kendall's $\\tau$")) + 
  ylab("Empirical power") + 
  theme_bw() + 
  theme(legend.position = "bottom", 
        
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 13), 
        
        strip.text = element_text(size = 12, face = "bold", color = "white"), 
        strip.background = element_rect(fill = "black"),
        
        legend.title = element_text(size = 13, face = "bold"), 
        legend.text = element_text(size = 12), 
        
        plot.title = element_text(size = 14, face = "bold"), 
        plot.subtitle = element_text(size = 13),
        plot.caption = element_text(size = 12, hjust = 0)
  ) + 
  labs(color = "Estimation method") + 
  scale_color_aaas() + 
  labs(title = plot_title, subtitle = plot_subtitle) + 
  scale_x_continuous(expand = c(0.01, 0.01)) + 
  scale_y_continuous(expand = c(0.0, 0.01))


ggsave(file.path(here(), "simulation2.pdf"), 
       p,
       width = 8.5,
       height = 11,
       units = "in",
       device = "pdf")



type1 <- results  %>% 
  select(-c(dcor, hhg, mic)) %>% 
  pivot_longer(cols = -c(p, n, tau)) %>% 
  mutate(n = case_when(n == 200 ~ 250, 
                       TRUE ~ n)) %>%
  filter(p != 3) %>% 
  mutate(p = case_when(p == 1 ~  "Gaussian copula", 
                       p == 2 ~ "Gumbel copula", 
                       p == 3 ~ "Frank copula", 
                       p == 4 ~ "Clayton copula")) %>% 
  mutate(name = case_when(name == "mic" ~ "MIC", 
                          name == "fkde" ~ "fastMI", 
                          name == "jmi" ~ "JMI", 
                          name == "dcor" ~ "dCor", 
                          name == "hhg" ~ "HHG")) %>% 
  mutate(n = paste0("n = ", n)) %>%
  filter(tau == 0) %>% 
  mutate(value = round(value, 2))
