for i in $( echo 100 250); do
  for j in $( seq 0 0.05 0.05); do
    export sampsize=$i
    export signal=$j
    sbatch /home/soumikp/2022_jmva/code/simulation1_base.sh
  done
done